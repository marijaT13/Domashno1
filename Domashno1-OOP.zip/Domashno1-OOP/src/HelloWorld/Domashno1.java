package HelloWorld;

public class Domashno1 {

	public static void main(String[] args) {
		String subject=new String ("OOP");
		String faculty=new String("FIKT");
		System.out.println("Hello World "+ subject+" "+faculty+".");

	}

}
